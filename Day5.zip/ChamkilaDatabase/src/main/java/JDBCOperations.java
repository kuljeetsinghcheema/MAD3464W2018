
import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 726293
 */
public class JDBCOperations {
    
       static Connection conn;
   static PreparedStatement stmt;
   static ResultSet rs;
   static String USER = "root";
   static String PASS = "";
   
   public static void main(String [] args)
   {
       connectDB();
       System.out.println("------------------------------------------------------------------------");
       selectDB();
       System.out.println("------------------------------------------------------------------------");
       insertDB();
       System.out.println("------------------------------------------------------------------------");
       selectDB();
       
   }
   
   static void connectDB()
   {
       try
       {
           Class.forName("com.mysql.jdbc.Driver");
           conn = DriverManager.getConnection("jdbc:mysql://localhost/MAD3464W18", USER, PASS);
           
       }
       catch(Exception ex)
               {
                   ex.printStackTrace();
               }
   }
   
   static void insertDB() 
   {
       try
       {
      stmt = conn.prepareStatement("Insert Into Person Values(?,?,?,?)");
      stmt.setInt(1 , 1002);
      stmt.setString(2,"Gurpreet");
      stmt.setString(3,"Singh");
      stmt.setInt(4,80);
      
      int i = stmt.executeUpdate();
      System.out.println(i+" records inserted ");
              }
       catch(Exception ex)
               {
                   ex.printStackTrace();
               }
   }
   
   static void selectDB()
   {
       try
       {
           stmt = conn.prepareStatement("SELECT * FROM Person");
           rs = stmt.executeQuery();
        
           
           while(rs.next())
           {
               System.out.println("ID: " +rs.getInt(1)+ " Name: " +rs.getString("First Name")+ "" +rs.getString("Last Name")+ " Age: " +rs.getInt("Age"));
           }
       }
       catch(Exception ex)
       {
           ex.printStackTrace();
       }
   }
   
   static void deleteDB()
   {
   try{
       
   }
   }
}
