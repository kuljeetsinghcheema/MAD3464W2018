/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day.pkg1.task.pkg2;

/**
 *
 * @author macstudent
 */
public class Day1Task2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         int row,col,n;

   n=5;
// n = number.nextInt();
 for(row=0;row<n;row++)
   {
 
       System.out.println();
 
       for(col=1; col<=n-row; col++)
        {  
         //System.out.print("col");
         
         System.out.print(col+" ");
     
        }
       // System.out.print(col);
     
       for(col=1;col<2*row;col++)
          {
          // System.out.print("col");
         
            System.out.print("  ");
     
          }
     
       for(col=n-row;col>0;col--)
          {
            if(col==5){
             
              continue;
             }
     
             else
               {
                 System.out.print(col+" ");
                }
           
          }
 
   //System.out.println();
 
          }


   for(row=2;row<=n;row++)
   {
       System.out.println();
   
           for(col=1;col<=row;col++)
             {
                System.out.print(col+" ");
              }
   
           for (col = 2*(n - row); col > 1; col--)
             {
                 System.out.print("  ");
     
             }
           for(col=row;col>0;col--)
              {
   
               if(col == 5)
              {
                continue;
              }
             else{
               System.out.print(col+" ");
              }
             }
   
    }


    }
    
}
