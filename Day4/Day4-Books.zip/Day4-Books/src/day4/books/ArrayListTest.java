/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4.books;

import java.util.ArrayList;

/**
 *
 * @author macstudent
 */
public class ArrayListTest {
    
    public static void main(String[] args) {
        // TODO code application logic here
        
       Books book1 = new Books(1,"The Sky",8);
       Books book2 = new Books(2,"Necklace",3);
       Books book3 = new Books(3,"Milk",2);
       Books book4 = new Books(4,"Journey",3);
       Books book5 = new Books(5,"Wonderer",4);
       
       
       ArrayList<Books> library = new ArrayList<Books>() ;
       library.add(book1);
       library.add(book2);
       library.add(book3);
       library.add(book4);
       library.add(book5);
       
       System.out.println("No. of Books : " + library.size());
       
       for (Books bk: library){
           bk.displayInfo();
       }

    }
    
}
